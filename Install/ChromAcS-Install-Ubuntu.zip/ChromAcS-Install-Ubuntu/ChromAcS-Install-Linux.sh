#!/usr/bin/env bash
# ChromAcS-Install-Linux.sh — Linux/WSL launcher
set -Eeuo pipefail

# Resolve this script's directory
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"; SOURCE="$(readlink "$SOURCE")"; [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"; done
DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"

INSTALL="$DIR/INSTALL_CHROMACS.sh"
if [ ! -f "$INSTALL" ]; then
  echo "INSTALL_CHROMACS.sh not found in this folder."
  read -n1 -rsp "Press any key to exit..."
  exit 1
fi

chmod +x "$INSTALL"

# If already in a terminal, run directly
if [ -t 1 ]; then
  bash "$INSTALL"
  exit $?
fi

# Try to spawn a terminal
for term in x-terminal-emulator gnome-terminal konsole xfce4-terminal mate-terminal lxterminal xterm; do
  if command -v "$term" >/dev/null 2>&1; then
    "$term" -e bash -lc "cd \"$DIR\"; ./INSTALL_CHROMACS.sh; echo; read -n1 -rsp 'Press any key to close...' " &
    exit 0
  fi
done

# Fallback
bash "$INSTALL"
