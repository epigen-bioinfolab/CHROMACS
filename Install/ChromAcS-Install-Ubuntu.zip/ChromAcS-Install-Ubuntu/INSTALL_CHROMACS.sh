#!/usr/bin/env bash
# ChromAcS publish installer
# Usage:
#   chmod +x INSTALL_CHROMACS.sh && ./INSTALL_CHROMACS.sh
# Customization via env vars:
#   CHROMACS_REPO_URL   (default: https://github.com/epigen-bioinfolab/CHROMACS.git)
#   CHROMACS_REPO_DIR   (default: $HOME/CHROMACS)
#   CHROMACS_CONDA_HOME (default: $HOME/.chromacs/miniconda3)
#   CHROMACS_ENV_NAME   (default: chromacs)
set -Eeuo pipefail

REPO_URL="${CHROMACS_REPO_URL:-https://github.com/epigen-bioinfolab/CHROMACS.git}"
REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/CHROMACS}"
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
LAUNCHER_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.local/share/applications"
LOG_DIR="$HOME/.chromacs"
LOG_FILE="$LOG_DIR/install_chromacs.log"

mkdir -p "$LOG_DIR" "$LAUNCHER_DIR" "$APP_DIR"

blue()  { printf "\033[1;34m%s\033[0m\n" "$*"; }
green() { printf "\033[1;32m%s\033[0m\n" "$*"; }
yellow(){ printf "\033[1;33m%s\033[0m\n" "$*"; }
red()   { printf "\033[1;31m%s\033[0m\n" "$*"; }
step()  { blue "==> $*"; }
sub()   { printf "    - %s\n" "$*"; }
die()   { red "ERROR: $*"; echo "See log: $LOG_FILE"; exit 1; }

trap 'red "A step failed. Log tail:"; tail -n 120 "$LOG_FILE" 2>/dev/null || true' ERR

UNAME_S="$(uname -s)"
UNAME_M="$(uname -m)"
IS_WSL="false"; grep -qi microsoft /proc/version 2>/dev/null && IS_WSL="true"

# ---------------- Package manager detection ----------------
PM=""
if [ "$UNAME_S" = "Darwin" ]; then
  PM="brew"
else
  command -v apt-get >/dev/null 2>&1 && PM="apt"
  command -v dnf     >/dev/null 2>&1 && PM="${PM:-dnf}"
  command -v yum     >/dev/null 2>&1 && PM="${PM:-yum}"
  command -v zypper  >/dev/null 2>&1 && PM="${PM:-zypper}"
  command -v pacman  >/dev/null 2>&1 && PM="${PM:-pacman}"
fi
[ -z "$PM" ] && die "Unsupported OS or package manager"

SUDO="sudo"; command -v sudo >/dev/null 2>&1 || SUDO=""

apt_pkg_installed()    { dpkg -s "$1" >/dev/null 2>&1; }
rpm_pkg_installed()    { rpm -q "$1"  >/dev/null 2>&1; }
pacman_pkg_installed() { pacman -Qi "$1" >/dev/null 2>&1; }
brew_pkg_installed()   { brew ls --versions "$1" >/dev/null 2>&1; }

pm_install_if_missing() {
  case "$PM" in
    apt)
      local missing=()
      for p in "$@"; do apt_pkg_installed "$p" || missing+=("$p"); done
      if [ "${#missing[@]}" -gt 0 ]; then
        $SUDO apt-get update -y >>"$LOG_FILE" 2>&1
        $SUDO apt-get install -y --no-install-recommends "${missing[@]}" >>"$LOG_FILE" 2>&1
      fi ;;
    dnf)
      local missing=(); for p in "$@"; do rpm_pkg_installed "$p" || missing+=("$p"); done
      [ "${#missing[@]}" -gt 0 ] && $SUDO dnf install -y "${missing[@]}" >>"$LOG_FILE" 2>&1 ;;
    yum)
      local missing=(); for p in "$@"; do rpm_pkg_installed "$p" || missing+=("$p"); done
      [ "${#missing[@]}" -gt 0 ] && $SUDO yum install -y "${missing[@]}" >>"$LOG_FILE" 2>&1 ;;
    zypper)
      local missing=(); for p in "$@"; do rpm_pkg_installed "$p" || missing+=("$p"); done
      [ "${#missing[@]}" -gt 0 ] && $SUDO zypper --non-interactive install "${missing[@]}" >>"$LOG_FILE" 2>&1 ;;
    pacman)
      local missing=(); for p in "$@"; do pacman_pkg_installed "$p" || missing+=("$p"); done
      [ "${#missing[@]}" -gt 0 ] && $SUDO pacman -Sy --noconfirm "${missing[@]}" >>"$LOG_FILE" 2>&1 ;;
    brew)
      for p in "$@"; do brew_pkg_installed "$p" || brew install "$p" >>"$LOG_FILE" 2>&1 || true; done ;;
  esac
}

# 1) Prereqs (install only if missing)
step "Installing prerequisites (git, curl/wget, aria2, build tools, fonts)"
case "$PM" in
  apt)    pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig build-essential libxtst6 libxrender1 libxext6 libsm6 fonts-dejavu-core ;;
  dnf|yum)pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig make gcc gcc-c++ libXext libXrender libXtst libSM ;;
  zypper) pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig gcc gcc-c++ make libXext6 libXrender1 libXtst6 libSM6 ;;
  pacman) pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig base-devel libxext libxrender libxtst libsm ;;
  brew)   pm_install_if_missing git curl aria2 wget coreutils gnu-sed fontconfig ;;
esac

# 2) Install Miniconda (per-user) if missing
fetch_url() {
  # fetch_url <url> <outfile>
  local url="$1"; local out="$2"
  : >"$out"
  if command -v aria2c >/dev/null 2>&1; then
    aria2c -c -x 16 -s 16 -o "$out" "$url" >>"$LOG_FILE" 2>&1 && [ -s "$out" ] && return 0
  fi
  curl -fL --retry 3 --retry-delay 2 -o "$out" "$url" >>"$LOG_FILE" 2>&1 && [ -s "$out" ] && return 0
  wget -O "$out" "$url" >>"$LOG_FILE" 2>&1 && [ -s "$out" ] && return 0
  return 1
}

install_miniconda() {
  if [ -x "$CONDA_HOME/bin/conda" ]; then
    sub "Miniconda already present at $CONDA_HOME"
    return
  fi
  step "Installing Miniconda to $CONDA_HOME"
  mkdir -p "$(dirname "$CONDA_HOME")"
  local os_id arch_id url inst
  if [ "$UNAME_S" = "Darwin" ]; then os_id="MacOSX"; else os_id="Linux"; fi
  case "$UNAME_M" in
    x86_64) arch_id="x86_64" ;;
    aarch64|arm64) arch_id="aarch64" ;;
    *) die "Unsupported arch: $UNAME_M" ;;
  esac
  url="https://repo.anaconda.com/miniconda/Miniconda3-latest-${os_id}-${arch_id}.sh"
  inst="$(mktemp -t miniconda.XXXXXX.sh)"
  fetch_url "$url" "$inst" || die "Failed to download Miniconda from $url"
  bash "$inst" -b -p "$CONDA_HOME" >>"$LOG_FILE" 2>&1 || die "Miniconda installer failed"
  rm -f "$inst"
  [ -x "$CONDA_HOME/bin/conda" ] || die "Miniconda did not install correctly"
  green "Miniconda installed."
}
install_miniconda

# Load conda into current shell and persist to rc
# shellcheck disable=SC1091
source "$CONDA_HOME/etc/profile.d/conda.sh" || die "Could not source conda.sh"
if ! grep -q "$CONDA_HOME/etc/profile.d/conda.sh" "$HOME/.bashrc" 2>/dev/null; then
  echo "source \"$CONDA_HOME/etc/profile.d/conda.sh\" 2>/dev/null || true" >> "$HOME/.bashrc"
fi
if [ -f "$HOME/.zshrc" ] && ! grep -q "$CONDA_HOME/etc/profile.d/conda.sh" "$HOME/.zshrc" 2>/dev/null; then
  echo "source \"$CONDA_HOME/etc/profile.d/conda.sh\" 2>/dev/null || true" >> "$HOME/.zshrc"
fi

# 3) Accept Anaconda ToS for defaults channels (if supported)
step "Accepting Anaconda channel ToS (if your conda supports it)"
conda --version >>"$LOG_FILE" 2>&1 || true
if conda tos --help >>"$LOG_FILE" 2>&1; then
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main   >>"$LOG_FILE" 2>&1 || true
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r      >>"$LOG_FILE" 2>&1 || true
else
  yellow "This conda has no 'tos' command; will avoid defaults if necessary."
fi

# Prefer conda-forge + bioconda, then defaults (ToS accepted)
conda config --set channel_priority flexible >>"$LOG_FILE" 2>&1 || true
conda config --add channels conda-forge >>"$LOG_FILE" 2>&1 || true
conda config --add channels bioconda    >>"$LOG_FILE" 2>&1 || true
conda config --add channels defaults    >>"$LOG_FILE" 2>&1 || true

# 4) Fetch ChromAcS repository
step "Fetching ChromAcS repository"
if [ -d "$REPO_DIR/.git" ]; then
  sub "Updating $REPO_DIR"
  git -C "$REPO_DIR" fetch --all >>"$LOG_FILE" 2>&1 || true
  git -C "$REPO_DIR" reset --hard origin/main >>"$LOG_FILE" 2>&1 || git -C "$REPO_DIR" pull >>"$LOG_FILE" 2>&1 || true
else
  git clone "$REPO_URL" "$REPO_DIR" >>"$LOG_FILE" 2>&1
fi

ENV_YML="$REPO_DIR/environment.yml"
[ -f "$ENV_YML" ] || die "environment.yml not found at $ENV_YML"

# 5) Install 'mamba' in base to speed solves (still conda)
step "Installing 'mamba' in base for faster solves"
conda install -n base -y -c conda-forge mamba >>"$LOG_FILE" 2>&1 || true

# 6) Create/Update environment (fallback to forge+bioconda only)
step "Creating/Updating conda environment '$ENV_NAME' from environment.yml"
if conda env list | grep -qE "^[[:space:]]*$ENV_NAME[[:space:]]"; then
  if ! mamba env update -n "$ENV_NAME" -f "$ENV_YML" >>"$LOG_FILE" 2>&1; then
    yellow "Retrying with channel override (conda-forge + bioconda only)"
    mamba env update -n "$ENV_NAME" -f "$ENV_YML" --override-channels -c conda-forge -c bioconda >>"$LOG_FILE" 2>&1 || conda env update -n "$ENV_NAME" -f "$ENV_YML" --override-channels -c conda-forge -c bioconda >>"$LOG_FILE" 2>&1
  fi
else
  if ! mamba env create -n "$ENV_NAME" -f "$ENV_YML" >>"$LOG_FILE" 2>&1; then
    yellow "Retrying with channel override (conda-forge + bioconda only)"
    mamba env create -n "$ENV_NAME" -f "$ENV_YML" --override-channels -c conda-forge -c bioconda >>"$LOG_FILE" 2>&1 || conda env create -n "$ENV_NAME" -f "$ENV_YML" --override-channels -c conda-forge -c bioconda >>"$LOG_FILE" 2>&1
  fi
fi

# 7) Install ChromAcS package (GUI + Add-On) - FIXED to pass correct repo path
step "Installing ChromAcS Python package"
export REPO_DIR  # ensure child processes inherit
# prefer editable; on failure, non-editable
if ! conda run -n "$ENV_NAME" python -m pip install -e "$REPO_DIR" >>"$LOG_FILE" 2>&1; then
  conda run -n "$ENV_NAME" python -m pip install "$REPO_DIR" >>"$LOG_FILE" 2>&1 || true
fi

# 8) Create robust launchers (module first; fallback to source tree)
step "Creating launchers in $LAUNCHER_DIR"
mkdir -p "$LAUNCHER_DIR"
cat > "$LAUNCHER_DIR/chromacs" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
# shellcheck disable=SC1091
source "$CONDA_HOME/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"
if "$CONDA_PREFIX/bin/python" -c "import chromacs" 2>/dev/null; then
  exec "$CONDA_PREFIX/bin/python" -m chromacs.chromacs_13c "$@"
else
  REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/CHROMACS}"
  export PYTHONPATH="$REPO_DIR:$PYTHONPATH"
  exec "$CONDA_PREFIX/bin/python" "$REPO_DIR/chromacs/chromacs_13c.py" "$@"
fi
EOS
chmod +x "$LAUNCHER_DIR/chromacs"

cat > "$LAUNCHER_DIR/chromacs-addon" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
# shellcheck disable=SC1091
source "$CONDA_HOME/etc/profile.d/conda.sh"
conda activate "$ENV_NAME"
if "$CONDA_PREFIX/bin/python" -c "import chromacs" 2>/dev/null; then
  exec "$CONDA_PREFIX/bin/python" -m chromacs.chromacs_addon "$@"
else
  REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/CHROMACS}"
  export PYTHONPATH="$REPO_DIR:$PYTHONPATH"
  exec "$CONDA_PREFIX/bin/python" "$REPO_DIR/chromacs/chromacs_addon.py" "$@"
fi
EOS
chmod +x "$LAUNCHER_DIR/chromacs-addon"

# 9) Create a .desktop entry (Linux/WSL) for menu/Start
if [ "$UNAME_S" != "Darwin" ]; then
  ICON_PATH="$REPO_DIR/chromacs/assets/icon.png"
  [ -f "$ICON_PATH" ] || ICON_PATH="/usr/share/icons/hicolor/64x64/apps/utilities-terminal.png"
  cat > "$APP_DIR/chromacs.desktop" <<EOD
[Desktop Entry]
Type=Application
Name=ChromAcS (GUI)
Comment=Chromatin Accessibility Analysis Suite
Exec=$LAUNCHER_DIR/chromacs
Icon=$ICON_PATH
Terminal=false
Categories=Science;Biology;
EOD
fi

# 10) Ensure ~/.local/bin on PATH now and persist
export PATH="$HOME/.local/bin:$PATH"
grep -q '\.local/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
if [ -f "$HOME/.zshrc" ]; then
  grep -q '\.local/bin' "$HOME/.zshrc" 2>/dev/null || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
fi
hash -r 2>/dev/null || true

# 11) Helpful WSL GUI hint
if [ "$IS_WSL" = "true" ] && [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
  yellow "WSL detected but no GUI display variables (DISPLAY/WAYLAND_DISPLAY)."
  echo "  - On Windows 11 with WSLg: run 'wsl --update' in an elevated PowerShell, then 'wsl --shutdown' and reopen."
  echo "  - Or use an X server (VcXsrv) and 'export DISPLAY=\$(grep -m1 nameserver /etc/resolv.conf | awk '{print \$2}'):0'"
fi

# 12) Final checks
step "Final checks"
if ! command -v chromacs >/dev/null 2>&1; then
  yellow "chromacs launcher not on PATH yet; adding for this shell"
  export PATH="$HOME/.local/bin:$PATH"
fi

# Verify Python import in env
if ! conda run -n "$ENV_NAME" python -c "import chromacs" >>"$LOG_FILE" 2>&1; then
  yellow "Package import failed in env; launcher will run from source."
else
  sub "Package import OK inside env."
fi

green "ChromAcS installed. Use:"
echo "  chromacs          # GUI"
echo "  chromacs-addon    # Add-on"
echo "Full log: $LOG_FILE"
