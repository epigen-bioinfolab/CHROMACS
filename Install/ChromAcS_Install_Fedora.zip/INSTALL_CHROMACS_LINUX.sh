#!/usr/bin/env bash
# ChromAcS installer (Fedora-friendly, v9)

set -Eeuo pipefail

REPO_URL="${CHROMACS_REPO_URL:-https://github.com/epigen-bioinfolab/CHROMACS.git}"
REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/CHROMACS}"
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
RELAX_TK="${CHROMACS_RELAX_TK:-1}"
INSTALL_DESKTOP="${CHROMACS_INSTALL_DESKTOP:-0}"
SANITY_PATH="${CHROMACS_SANITY_PATH:-}"
SKIP_OS_CHECKS="${CHROMACS_SKIP_OS_CHECKS:-0}"
USE_MICROMAMBA="${CHROMACS_USE_MICROMAMBA:-0}"

LAUNCHER_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"

TS="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="$HOME/.chromacs/install-$TS.log"

# Pretty printers
green(){ printf "\033[1;32m%s\033[0m\n" "$*"; }
yellow(){ printf "\033[1;33m%s\033[0m\n" "$*"; }
red(){ printf "\033[1;31m%s\033[0m\n" "$*"; }
blue(){ printf "\033[1;34m%s\033[0m\n" "$*"; }
step(){ green "==> $*"; }
sub(){ printf "    - %s\n" "$*"; }
die(){ red "ERROR: $*"; echo "See log: $LOG_FILE"; exit 1; }

have(){ command -v "$1" >/dev/null 2>&1; }
need(){ have "$1" || die "Missing required command: $1"; }

ensure_dir(){
  local d="$1"
  if [ -d "$d" ]; then
    return 0
  elif [ -e "$d" ]; then
    die "Path exists but is not a directory: $d"
  else
    mkdir -p "$d" 2>/dev/null || install -d -m 755 "$d" || die "Failed to create directory: $d"
  fi
}

# Download helper with fallback
safe_download(){
  local url="$1"
  local output="$2"
  
  if have aria2c; then
    aria2c -x 4 -s 4 -d "$(dirname "$output")" -o "$(basename "$output")" "$url" 2>&1 | tee -a "$LOG_FILE" || \
    curl -fsSL "$url" -o "$output"
  elif have curl; then
    curl -fsSL "$url" -o "$output"
  elif have wget; then
    wget -q -O "$output" "$url"
  else
    die "No download tool available (aria2c, curl, or wget required)"
  fi
}

# Prepare base dirs
ensure_dir "$HOME/.chromacs"
ensure_dir "$LAUNCHER_DIR"
ensure_dir "$DESKTOP_DIR"

: > "$LOG_FILE" || true

UNAME_S="$(uname -s)"
UNAME_M="$(uname -m)"
IS_ROOT=0; [ "$(id -u)" -eq 0 ] && IS_ROOT=1

# Detect package manager
PM=""
if [ "$UNAME_S" = "Darwin" ]; then
  PM="brew"
else
  have apt-get && PM="apt"
  have dnf     && PM="${PM:-dnf}"
  have yum     && PM="${PM:-yum}"
  have zypper  && PM="${PM:-zypper}"
  have pacman  && PM="${PM:-pacman}"
fi
[ -z "$PM" ] && die "Unsupported OS or package manager"
step "Detected OS: $UNAME_S, pkg manager: $PM"

# Request elevated privileges only when needed
as_root(){
  if [ "$IS_ROOT" -eq 1 ]; then
    "$@"
  else
    if have sudo; then
      sudo -p "ChromAcS needs your password to install missing OS packages: " "$@"
    else
      die "Need to run as root to execute: $* (sudo not available)"
    fi
  fi
}

# SELinux warning (Fedora)
if have getenforce; then
  SELINUX_MODE="$(getenforce || true)"
  if [ "$SELINUX_MODE" = "Enforcing" ]; then
    yellow "SELinux is Enforcing. If you encounter denials, consider:"
    yellow "  sealert -a /var/log/audit/audit.log"
  fi
fi

# Helpers to check installed packages per PM
apt_installed(){ dpkg -s "$1" >/dev/null 2>&1; }
rpm_installed(){ rpm -q "$1" >/dev/null 2>&1; }
pac_installed(){ pacman -Qi "$1" >/dev/null 2>&1; }
brew_installed(){ brew ls --versions "$1" >/dev/null 2>&1; }

pm_install_if_missing(){
  if [ "$SKIP_OS_CHECKS" = "1" ]; then
    yellow "Skipping OS package checks/installs (CHROMACS_SKIP_OS_CHECKS=1)."
    return 0
  fi
  local missing=()
  case "$PM" in
    apt)
      for p in "$@"; do apt_installed "$p" || missing+=("$p"); done
      if [ "${#missing[@]}" -gt 0 ]; then
        sub "Missing packages (apt): ${missing[*]}"
        as_root apt-get update -y 2>&1 | tee -a "$LOG_FILE"
        as_root apt-get install -y --no-install-recommends "${missing[@]}" 2>&1 | tee -a "$LOG_FILE"
      else
        sub "All prerequisites present (apt) — no sudo prompt needed."
      fi
      ;;
    dnf|yum)
      for p in "$@"; do rpm_installed "$p" || missing+=("$p"); done
      if [ "${#missing[@]}" -gt 0 ]; then
        sub "Missing packages ($PM): ${missing[*]}"
        if [ "$PM" = "dnf" ]; then
          as_root dnf install -y "${missing[@]}" 2>&1 | tee -a "$LOG_FILE"
        else
          as_root yum install -y "${missing[@]}" 2>&1 | tee -a "$LOG_FILE"
        fi
      else
        sub "All prerequisites present ($PM) — no sudo prompt needed."
      fi
      ;;
    zypper)
      for p in "$@"; do rpm_installed "$p" || missing+=("$p"); done
      if [ "${#missing[@]}" -gt 0 ]; then
        sub "Missing packages (zypper): ${missing[*]}"
        as_root zypper --non-interactive install "${missing[@]}" 2>&1 | tee -a "$LOG_FILE"
      else
        sub "All prerequisites present (zypper) — no sudo prompt needed."
      fi
      ;;
    pacman)
      for p in "$@"; do pac_installed "$p" || missing+=("$p"); done
      if [ "${#missing[@]}" -gt 0 ]; then
        sub "Missing packages (pacman): ${missing[*]}"
        as_root pacman -Sy --noconfirm "${missing[@]}" 2>&1 | tee -a "$LOG_FILE"
      else
        sub "All prerequisites present (pacman) — no sudo prompt needed."
      fi
      ;;
    brew)
      local to_install=()
      for p in "$@"; do brew_installed "$p" || to_install+=("$p"); done
      if [ "${#to_install[@]}" -gt 0 ]; then
        sub "Installing (brew): ${to_install[*]}"
        brew install "${to_install[@]}" 2>&1 | tee -a "$LOG_FILE" || true
      else
        sub "All prerequisites present (brew)."
      fi
      ;;
  esac
}

# 1) Prereqs (install only if missing)
step "Installing prerequisites (git, curl/wget, aria2, build tools, fonts, X11)"
case "$PM" in
  apt)
    pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig make gcc g++ libxext6 libxrender1 libxtst6 libsm6 fonts-dejavu-core tk xvfb
    ;;
  dnf|yum)
    # Fedora: include DejaVu fonts, mesa-libGL, tk, and X11 dependencies
    pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig make gcc gcc-c++ libXext libXrender libXtst libSM mesa-libGL dejavu-sans-fonts dejavu-serif-fonts tk xorg-x11-server-Xvfb libX11
    ;;
  zypper)
    pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig gcc gcc-c++ make libXext6 libXrender1 libXtst6 libSM6 tk xvfb
    ;;
  pacman)
    pm_install_if_missing git curl wget aria2 bzip2 ca-certificates fontconfig base-devel libxext libxrender libxtst libsm ttf-dejavu tk xorg-server-xvfb
    ;;
  brew)
    pm_install_if_missing git aria2
    ;;
esac

# 2) Clone or update repo
step "Preparing repository at $REPO_DIR"
if [ -d "$REPO_DIR/.git" ]; then
  sub "Repository exists. Pulling latest..."
  (cd "$REPO_DIR" && git pull --rebase) 2>&1 | tee -a "$LOG_FILE" || true
elif [ -d "$REPO_DIR" ]; then
  yellow "Directory $REPO_DIR exists (no .git). Using as-is."
else
  need git
  sub "Cloning $REPO_URL"
  git clone "$REPO_URL" "$REPO_DIR" 2>&1 | tee -a "$LOG_FILE"
fi

ENV_YML="$REPO_DIR/environment.yml"
[ -f "$ENV_YML" ] || die "environment.yml not found at $ENV_YML"

# 3) Install Miniconda or Micromamba (per-user) if missing
step "Bootstrapping package manager (user-local)"
if [ "$USE_MICROMAMBA" = "1" ]; then
  # Micromamba installation
  MICROMAMBA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/micromamba}"
  ensure_dir "$MICROMAMBA_HOME"
  if [ ! -x "$MICROMAMBA_HOME/micromamba" ]; then
    case "$UNAME_M" in
      x86_64|amd64) MICRO_ARCH="x86_64" ;;
      aarch64|arm64) MICRO_ARCH="aarch64" ;;
      *) MICRO_ARCH="x86_64" ;;
    esac
    MICRO_URL="https://micro.mamba.pm/api/micromamba/linux-${MICRO_ARCH}/latest"
    sub "Downloading micromamba from $MICRO_URL"
    safe_download "$MICRO_URL" "$MICROMAMBA_HOME/micromamba"
    chmod +x "$MICROMAMBA_HOME/micromamba"
    CONDA_HOME="$MICROMAMBA_HOME"
  else
    sub "Micromamba already present."
    CONDA_HOME="$MICROMAMBA_HOME"
  fi
else
  # Miniconda installation
  if [ ! -x "$CONDA_HOME/bin/conda" ]; then
    ensure_dir "$(dirname "$CONDA_HOME")"
    case "$UNAME_M" in
      x86_64|amd64) MINI_ARCH="x86_64" ;;
      aarch64|arm64) MINI_ARCH="aarch64" ;;
      *) MINI_ARCH="x86_64" ;;
    esac
    MINI_URL="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-${MINI_ARCH}.sh"
    INSTALL_SH="$HOME/.chromacs/miniconda-installer.sh"
    sub "Downloading Miniconda from $MINI_URL"
    safe_download "$MINI_URL" "$INSTALL_SH"
    # Use explicit sh to avoid shell detection issues on Fedora 33+
    sh "$INSTALL_SH" -b -p "$CONDA_HOME" 2>&1 | tee -a "$LOG_FILE"
    rm -f "$INSTALL_SH"
  else
    sub "Miniconda already present."
  fi
fi

# 4) Initialize conda/micromamba and install mamba for faster solves
step "Initializing package manager and installing mamba"
if [ "$USE_MICROMAMBA" = "1" ]; then
  export MAMBA_ROOT_PREFIX="$CONDA_HOME"
  eval "$("$CONDA_HOME/micromamba" shell hook --shell bash)"
  "$CONDA_HOME/micromamba" config set always_yes yes
  "$CONDA_HOME/micromamba" config set changeps1 no
  "$CONDA_HOME/micromamba" config prepend channels conda-forge
  "$CONDA_HOME/micromamba" config prepend channels bioconda
  "$CONDA_HOME/micromamba" config prepend channels defaults
  "$CONDA_HOME/micromamba" config set channel_priority flexible
else
  eval "$("$CONDA_HOME/bin/conda" shell.bash hook)"
  # Force our preferred channel order; tolerate if keys already exist
  conda config --set always_yes yes --set changeps1 no 2>&1 | tee -a "$LOG_FILE" || true
  conda config --remove-key channels 2>/dev/null || true
  # Bioconda requires conda-forge first
  conda config --add channels conda-forge 2>&1 | tee -a "$LOG_FILE" || true
  conda config --add channels bioconda      2>&1 | tee -a "$LOG_FILE" || true
  conda config --add channels defaults      2>&1 | tee -a "$LOG_FILE" || true
  conda config --set channel_priority flexible 2>&1 | tee -a "$LOG_FILE" || true

  # Install mamba early for faster environment resolution
  if ! "$CONDA_HOME/bin/conda" list -n base mamba >/dev/null 2>&1; then
    sub "Installing mamba in base env for faster package solving"
    conda install -n base -c conda-forge mamba 2>&1 | tee -a "$LOG_FILE" || true
  fi
fi

# 4a) Accept Anaconda ToS for defaults channels if needed (Miniconda only)
if [ "$USE_MICROMAMBA" != "1" ]; then
  step "Accepting Anaconda Terms of Service (if required)"
  if conda --help 2>/dev/null | grep -q "tos"; then
    conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main 2>&1 | tee -a "$LOG_FILE" || true
    conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r    2>&1 | tee -a "$LOG_FILE" || true
    conda tos accept --channel defaults 2>&1 | tee -a "$LOG_FILE" || true
  else
    sub "Your conda version does not support 'conda tos'; proceeding."
  fi
fi

# 5) Prepare environment.yml (relax tk pin if strict)
TMP_ENV_YML="$ENV_YML"
if [ "$RELAX_TK" = "1" ]; then
  if grep -E '^[[:space:]]*-\s*tk=8\.6\.13' "$ENV_YML" >/dev/null 2>&1; then
    TMP_ENV_YML="$HOME/.chromacs/environment.relaxed.yml"
    sed -E 's/^([[:space:]]*-\s*tk)=8\.6\.13[^[:space:]]*/\1=8.6.*/' "$ENV_YML" > "$TMP_ENV_YML"
    sub "Relaxed tk pin -> using $TMP_ENV_YML"
  fi
fi

# 6) Create/Update env (no channel flags; rely on configured channels)
step "Creating/Updating conda env: $ENV_NAME"
if [ "$USE_MICROMAMBA" = "1" ]; then
  if ! "$CONDA_HOME/micromamba" env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
    "$CONDA_HOME/micromamba" create -n "$ENV_NAME" -f "$TMP_ENV_YML" 2>&1 | tee -a "$LOG_FILE"
  else
    "$CONDA_HOME/micromamba" update -n "$ENV_NAME" -f "$TMP_ENV_YML" --prune 2>&1 | tee -a "$LOG_FILE"
  fi
else
  if ! conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
    if have mamba; then
      mamba env create -n "$ENV_NAME" -f "$TMP_ENV_YML" 2>&1 | tee -a "$LOG_FILE" \
        || conda env create -n "$ENV_NAME" -f "$TMP_ENV_YML" 2>&1 | tee -a "$LOG_FILE"
    else
      conda env create -n "$ENV_NAME" -f "$TMP_ENV_YML" 2>&1 | tee -a "$LOG_FILE"
    fi
  else
    if have mamba; then
      mamba env update -n "$ENV_NAME" -f "$TMP_ENV_YML" --prune 2>&1 | tee -a "$LOG_FILE" \
        || conda env update -n "$ENV_NAME" -f "$TMP_ENV_YML" --prune 2>&1 | tee -a "$LOG_FILE"
    else
      conda env update -n "$ENV_NAME" -f "$TMP_ENV_YML" --prune 2>&1 | tee -a "$LOG_FILE"
    fi
  fi
fi

# 7) Install ChromAcS package into env
step "Installing ChromAcS (pip install .)"
if [ "$USE_MICROMAMBA" = "1" ]; then
  "$CONDA_HOME/micromamba" run -n "$ENV_NAME" python -m pip install --upgrade pip wheel setuptools 2>&1 | tee -a "$LOG_FILE"
  (cd "$REPO_DIR" && "$CONDA_HOME/micromamba" run -n "$ENV_NAME" python -m pip install .) 2>&1 | tee -a "$LOG_FILE"
else
  conda run -n "$ENV_NAME" python -m pip install --upgrade pip wheel setuptools 2>&1 | tee -a "$LOG_FILE"
  (cd "$REPO_DIR" && conda run -n "$ENV_NAME" python -m pip install .) 2>&1 | tee -a "$LOG_FILE"
fi

# 7a) Install missing packages identified by common sanity check issues
step "Installing commonly missing packages (R/Bioconductor fallback)"
if [ "$USE_MICROMAMBA" = "1" ]; then
  "$CONDA_HOME/micromamba" run -n "$ENV_NAME" python -m pip install fpdf 2>&1 | tee -a "$LOG_FILE"
  "$CONDA_HOME/micromamba" run -n "$ENV_NAME" R -e '
  if (!requireNamespace("BiocManager", quietly=TRUE)) {
      install.packages("BiocManager", repos="https://cloud.r-project.org")
  }
  missing_pkgs <- c("txdbmaker", "NOISeq")[!c("txdbmaker", "NOISeq") %in% installed.packages()[,"Package"]]
  if (length(missing_pkgs) > 0) {
      message("Installing missing Bioconductor packages: ", paste(missing_pkgs, collapse=", "))
      BiocManager::install(missing_pkgs, ask=FALSE, update=FALSE, version="3.20")
  } else {
      message("All required Bioconductor packages are already installed")
  }
  ' 2>&1 | tee -a "$LOG_FILE"
else
  conda run -n "$ENV_NAME" python -m pip install fpdf 2>&1 | tee -a "$LOG_FILE"
  conda run -n "$ENV_NAME" R -e '
  if (!requireNamespace("BiocManager", quietly=TRUE)) {
      install.packages("BiocManager", repos="https://cloud.r-project.org")
  }
  missing_pkgs <- c("txdbmaker", "NOISeq")[!c("txdbmaker", "NOISeq") %in% installed.packages()[,"Package"]]
  if (length(missing_pkgs) > 0) {
      message("Installing missing Bioconductor packages: ", paste(missing_pkgs, collapse=", "))
      BiocManager::install(missing_pkgs, ask=FALSE, update=FALSE, version="3.20")
  } else {
      message("All required Bioconductor packages are already installed")
  }
  ' 2>&1 | tee -a "$LOG_FILE"
fi

# 8) Create launchers - FIXED: Use absolute path to user-local conda/micromamba
step "Creating launchers in $LAUNCHER_DIR"
if [ "$USE_MICROMAMBA" = "1" ]; then
  cat >"$LAUNCHER_DIR/chromacs" <<EOF
#!/usr/bin/env bash
set -e
ENV_NAME="\${CHROMACS_ENV_NAME:-$ENV_NAME}"
CONDA_HOME="\${CHROMACS_CONDA_HOME:-$CONDA_HOME}"
export MAMBA_ROOT_PREFIX="\$CONDA_HOME"
eval "\$("\$CONDA_HOME/micromamba" shell hook --shell bash)"
exec "\$CONDA_HOME/micromamba" run -n "\$ENV_NAME" python -m chromacs.chromacs_13c "\$@"
EOF
else
  cat >"$LAUNCHER_DIR/chromacs" <<EOF
#!/usr/bin/env bash
set -e
ENV_NAME="\${CHROMACS_ENV_NAME:-$ENV_NAME}"
CONDA_HOME="\${CHROMACS_CONDA_HOME:-$CONDA_HOME}"
eval "\$("\$CONDA_HOME/bin/conda" shell.bash hook)"
exec "\$CONDA_HOME/bin/conda" run -n "\$ENV_NAME" python -m chromacs.chromacs_13c "\$@"
EOF
fi
chmod +x "$LAUNCHER_DIR/chromacs"

if [ "$USE_MICROMAMBA" = "1" ]; then
  cat >"$LAUNCHER_DIR/chromacs-addon" <<EOF
#!/usr/bin/env bash
set -e
ENV_NAME="\${CHROMACS_ENV_NAME:-$ENV_NAME}"
CONDA_HOME="\${CHROMACS_CONDA_HOME:-$CONDA_HOME}"
export MAMBA_ROOT_PREFIX="\$CONDA_HOME"
eval "\$("\$CONDA_HOME/micromamba" shell hook --shell bash)"
exec "\$CONDA_HOME/micromamba" run -n "\$ENV_NAME" python -m chromacs.chromacs_addon "\$@"
EOF
else
  cat >"$LAUNCHER_DIR/chromacs-addon" <<EOF
#!/usr/bin/env bash
set -e
ENV_NAME="\${CHROMACS_ENV_NAME:-$ENV_NAME}"
CONDA_HOME="\${CHROMACS_CONDA_HOME:-$CONDA_HOME}"
eval "\$("\$CONDA_HOME/bin/conda" shell.bash hook)"
exec "\$CONDA_HOME/bin/conda" run -n "\$ENV_NAME" python -m chromacs.chromacs_addon "\$@"
EOF
fi
chmod +x "$LAUNCHER_DIR/chromacs-addon"

# 9) Optional desktop entry (OFF by default; set CHROMACS_INSTALL_DESKTOP=1 to enable)
if [ "$INSTALL_DESKTOP" = "1" ]; then
  step "Installing desktop entry"
  cat >"$DESKTOP_DIR/chromacs.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=ChromAcS
Comment=ChromAcS GUI
Exec=/usr/bin/env chromacs
Icon=
Terminal=false
Categories=Science;Biology;
EOF
  blue "Desktop entry created at $DESKTOP_DIR/chromacs.desktop"
  blue "Note: You may want to add an icon path to the .desktop file manually"
else
  sub "Skipping desktop entry (CHROMACS_INSTALL_DESKTOP=0)."
  yellow "To enable desktop integration, set CHROMACS_INSTALL_DESKTOP=1 and re-run"
fi

# 10) Ensure ~/.local/bin on PATH for future shells
if ! printf "%s" "$PATH" | tr ':' '\n' | grep -qx "$HOME/.local/bin"; then
  yellow "~/.local/bin not on PATH. Appending to shell rc files."
  for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
    [ -f "$rc" ] || continue
    if ! grep -Fq 'export PATH="$HOME/.local/bin:$PATH"' "$rc"; then
      printf '\n# Added by ChromAcS installer\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$rc"
    fi
  done
  export PATH="$HOME/.local/bin:$PATH"
fi

# 11) Verify import
step "Verifying installation"
if [ "$USE_MICROMAMBA" = "1" ]; then
  if ! "$CONDA_HOME/micromamba" run -n "$ENV_NAME" python - <<'PY'
import sys
try:
    import chromacs
    print("OK: chromacs import", chromacs.__version__ if hasattr(chromacs, "__version__") else "")
    sys.exit(0)
except Exception as e:
    print("FAIL:", e)
    sys.exit(1)
PY
  then
    yellow "Package import failed in env; launcher will still run from source modules."
  else
    sub "Package import OK."
  fi
else
  if ! "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" python - <<'PY'
import sys
try:
    import chromacs
    print("OK: chromacs import", chromacs.__version__ if hasattr(chromacs, "__version__") else "")
    sys.exit(0)
except Exception as e:
    print("FAIL:", e)
    sys.exit(1)
PY
  then
    yellow "Package import failed in env; launcher will still run from source modules."
  else
    sub "Package import OK."
  fi
fi

# 12) Optional post-install sanity check
step "Running post-install sanity check (if present)"
if [ -n "$SANITY_PATH" ] && [ -f "$SANITY_PATH" ]; then
  SC="$SANITY_PATH"
else
  # search common locations
  for c in "$REPO_DIR/chromacs-sanity-check.sh" "$PWD/chromacs-sanity-check.sh" "$HOME/chromacs-sanity-check.sh"; do
    if [ -f "$c" ]; then SC="$c"; break; fi
  done
fi
if [ -n "${SC:-}" ]; then
  sub "Found sanity script: $SC"
  chmod 755 "$SC" 2>&1 | tee -a "$LOG_FILE" || true
  # Run inside the ChromAcS env
  if [ "$USE_MICROMAMBA" = "1" ]; then
    "$CONDA_HOME/micromamba" run -n "$ENV_NAME" bash "$SC" 2>&1 | tee -a "$LOG_FILE" || true
  else
    "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" bash "$SC" 2>&1 | tee -a "$LOG_FILE" || true
  fi
else
  sub "No sanity script found; skipping."
fi

green "All done!"
echo "You can now run: chromacs"
echo "Install log: $LOG_FILE"
if [ "$USE_MICROMAMBA" = "1" ]; then
  blue "Note: Used micromamba for faster installation (set CHROMACS_USE_MICROMAMBA=0 to use Miniconda)"
fi
if [ "$INSTALL_DESKTOP" = "0" ]; then
  yellow "Tip: Set CHROMACS_INSTALL_DESKTOP=1 for desktop integration"
fi
