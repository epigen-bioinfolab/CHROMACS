#!/usr/bin/env bash
# Report only missing tools/packages/modules for ChromAcS
# exit 0: all present, 2: missing items, 3: conda/env issue

set -uo pipefail

echo "checking ChromAcS associated tools/packages installation"

ENV_NAME="${ENV_NAME:-chromacs}"

# Find conda
CONDA_BIN="${CHROMACS_CONDA_BIN:-$HOME/.chromacs/miniconda3/bin/conda}"
if [ ! -x "$CONDA_BIN" ]; then
  if command -v conda >/dev/null 2>&1; then
    CONDA_BIN="$(command -v conda)"
  fi
fi
if [ ! -x "${CONDA_BIN:-/nope}" ]; then
  echo "ENV:conda-not-found"
  exit 3
fi

# Ensure env exists
if ! "$CONDA_BIN" env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
  echo "ENV:${ENV_NAME}-not-found"
  exit 3
fi

# Helper to run inside env without aborting script on failures
in_env() {
  "$CONDA_BIN" run -n "$ENV_NAME" bash -lc "$*" 2>/dev/null
}

missing=()



# ---------- CLI tools ----------
echo "checking CLI tools"
CLI_TOOLS=(
  "bowtie2"
  "samtools"
  "fastqc"
  "multiqc"
  "trim_galore"
  "macs3"
  "Genrich"
  "bedtools"
  "bamCoverage"    # deepTools
  "featureCounts"  # subread
  "meme"
  "fimo"
  "aria2c"
  "TOBIAS"
  "R"
)

for t in "${CLI_TOOLS[@]}"; do
  if ! in_env "command -v $t >/dev/null 2>&1"; then
    missing+=("CLI:${t}")
  fi
done




# ---------- R packages ----------
echo "checking R packages"

# Use R namespace names (not conda names)
R_PKGS=(
  "ChIPseeker" "DiffBind" "GenomicFeatures" "GenomicRanges" "rtracklayer"
  "clusterProfiler" "txdbmaker" "biomaRt" "NOISeq"
  "ggplot2" "gridExtra" "R.utils" "xml2" "openxlsx" "ggrepel"
)

tmpR="$(mktemp)"
cat > "$tmpR" <<'RS'
pkgs <- c(
  "ChIPseeker","DiffBind","GenomicFeatures","GenomicRanges","rtracklayer",
  "clusterProfiler","txdbmaker","biomaRt","NOISeq",
  "ggplot2","gridExtra","R.utils","xml2","openxlsx","ggrepel"
)
for (p in pkgs) {
  if (!requireNamespace(p, quietly=TRUE)) cat(p, "\n")
}
RS

if ! R_MISSING="$(in_env "Rscript \"$tmpR\"")"; then
  # If R itself is missing, CLI:R already reported; otherwise capture whatever we got
  R_MISSING=""
fi
rm -f "$tmpR"

if [ -n "$R_MISSING" ]; then
  while IFS= read -r line; do
    [ -n "$line" ] && missing+=("R:${line}")
  done <<< "$R_MISSING"
fi

# ---------- Python modules ----------
echo "checking python modules"
# map: label:import_name
declare -A PY_MAP=(
  [pandas]=pandas
  [numpy]=numpy
  [scipy]=scipy
  [statsmodels]=statsmodels
  [pyyaml]=yaml
  [openpyxl]=openpyxl
  [matplotlib]=matplotlib
  [seaborn]=seaborn
  [fpdf]=fpdf
  [pillow]=PIL
  [tk]=tkinter
)

tmpPY="$(mktemp)"
cat > "$tmpPY" <<'PY'
import importlib, sys
mods = {
  "pandas":"pandas",
  "numpy":"numpy",
  "scipy":"scipy",
  "statsmodels":"statsmodels",
  "pyyaml":"yaml",
  "openpyxl":"openpyxl",
  "matplotlib":"matplotlib",
  "seaborn":"seaborn",
  "fpdf":"fpdf",
  "pillow":"PIL",
  "tk":"tkinter",
}
missing = []
for label, modname in mods.items():
  try:
    m = importlib.import_module(modname)
    if label == "tk":
      # also exercise Tcl presence (no GUI)
      import tkinter
      tkinter.Tcl().call("info", "patchlevel")
  except Exception:
    missing.append(label)
print("\n".join(missing))
PY

if ! PY_MISSING="$(in_env "python \"$tmpPY\"")"; then
  PY_MISSING=""
fi
rm -f "$tmpPY"

if [ -n "$PY_MISSING" ]; then
  while IFS= read -r line; do
    [ -n "$line" ] && missing+=("PY:${line}")
  done <<< "$PY_MISSING"
fi

echo "check complete. report:"

# ---------- Output ----------
if [ "${#missing[@]}" -gt 0 ]; then
  printf "%s\n" "${missing[@]}"
  exit 2
else
  # Success: print nothing. Uncomment next line if you want a message.
  echo "OK: all required components present"
  exit 0
fi

