#!/usr/bin/env bash
# installer-linux.sh

set -Eeo pipefail
APP_NAME="ChromAcS"
VERSION="1.2.8"
WORK="$HOME/.chromacs"
REPO_URL="${REPO_URL:-https://github.com/epigen-bioinfolab/CHROMACS.git}"
REPO_DIR="${WORK}/CHROMACS"
ENV_NAME="${ENV_NAME:-chromacs}"
CONDA_HOME="${CONDA_HOME:-$WORK/miniconda3}"
LOG="${WORK}/install.log"

ts(){ date +"%H:%M:%S"; }
info(){ echo "[INFO $(ts)] $*" | tee -a "$LOG"; }
warn(){ echo "[WARN $(ts)] $*" | tee -a "$LOG"; }
ok(){   echo "[OK   $(ts)] $*" | tee -a "$LOG"; }
fail(){ echo "[FAIL $(ts)] $*" | tee -a "$LOG"; exit 1; }

mkdir -p "$WORK"; : > "$LOG"
have(){ command -v "$1" >/dev/null 2>&1; }

dl(){
  local url="$1" dest="$2"
  info "Downloading: $url"
  if have curl; then curl -fsSL --retry 5 --retry-all-errors -o "$dest" "$url" && return 0; fi
  if have aria2c; then aria2c -q -x 16 -s 4 -o "$(basename "$dest")" -d "$(dirname "$dest")" "$url" && return 0; fi
  if have wget; then wget -q -O "$dest" "$url" && return 0; fi
  if have python3; then
python3 - "$url" "$dest" <<'PY' || return 1
import sys,urllib.request
urllib.request.urlretrieve(sys.argv[1], sys.argv[2])
PY
    return 0
  fi
  fail "No downloader available (need curl/aria2c/wget/python3)."
}

install_miniconda(){
  if [ -x "$CONDA_HOME/bin/conda" ]; then ok "Miniconda already present"; return 0; fi
  mkdir -p "$WORK/tmp"
  local sh="$WORK/tmp/miniconda.sh"
  local os="$(uname -s)"
  local arch="$(uname -m)"
  local url
  if [ "$os" = "Darwin" ]; then
    if [ "$arch" = "arm64" ]; then url="https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-arm64.sh"
    else url="https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-x86_64.sh"; fi
  else
    case "$arch" in
      x86_64)  url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" ;;
      aarch64) url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-aarch64.sh" ;;
      *)       url="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" ;;
    esac
  fi
  dl "$url" "$sh"
  bash "$sh" -b -p "$CONDA_HOME" >>"$LOG" 2>&1 || fail "Miniconda installer failed"
  ok "Miniconda installed: $CONDA_HOME"
}

init_conda(){
  # shellcheck disable=SC1091
  . "$CONDA_HOME/etc/profile.d/conda.sh" || fail "Could not source conda.sh"
  conda config --set channel_priority flexible || true
  conda config --remove-key channels >/dev/null 2>&1 || true
  conda config --add channels conda-forge || true
  conda config --add channels bioconda || true
  conda config --add channels defaults || true
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main || true
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r || true
}

fetch_repo(){
  if have git; then
    if [ -d "$REPO_DIR/.git" ]; then
      info "Updating repository at $REPO_DIR"
      git -C "$REPO_DIR" pull --ff-only || warn "git pull failed; continuing"
    else
      info "Cloning repository to $REPO_DIR"
      git clone "$REPO_URL" "$REPO_DIR" || fail "git clone failed"
    fi
  else
    info "git not found; downloading source zip"
    local tmp="$WORK/tmp"
    mkdir -p "$tmp"
    local zip="$tmp/chromacs.zip"
    dl "https://github.com/epigen-bioinfolab/CHROMACS/archive/refs/heads/main.zip" "$zip"
    rm -rf "$REPO_DIR"
    mkdir -p "$REPO_DIR"
    unzip -q "$zip" -d "$tmp"
    local src
    src="$(find "$tmp" -maxdepth 1 -type d -name 'CHROMACS-*' | head -n1)"
    [ -n "$src" ] || fail "Could not find extracted repo folder"
    cp -R "$src"/. "$REPO_DIR"/
  fi
  ok "Repository ready"
}

create_env_from_yml(){
  info "Creating/Updating conda env: $ENV_NAME from environment.yml"
  if "$CONDA_HOME/bin/conda" env list | grep -qE "^[^#]*\\b$ENV_NAME\\b"; then
    "$CONDA_HOME/bin/conda" env update -n "$ENV_NAME" -f "$REPO_DIR/environment.yml" || fail "conda env update failed"
  else
    "$CONDA_HOME/bin/conda" env create -n "$ENV_NAME" -f "$REPO_DIR/environment.yml" || fail "conda env create failed"
  fi
  ok "Conda environment ready"
}

pip_install_package(){
  info "Installing ChromAcS python package"
  "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" python - <<'PY' || exit 70
import os, subprocess, sys
repo = os.environ.get("REPO_DIR") or os.path.expanduser("~/.chromacs/CHROMACS")
def run(args):
    print("+", " ".join(args), flush=True)
    subprocess.check_call(args)
run([sys.executable, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"])
# Try editable first, then sdist
try:
    run([sys.executable, "-m", "pip", "install", "-e", repo])
except subprocess.CalledProcessError:
    run([sys.executable, "-m", "pip", "install", repo])
try:
    __import__("chromacs")
    print("ChromAcS package import OK", flush=True)
except Exception as e:
    print("WARNING: Could not import package 'chromacs' yet:", e, flush=True)
PY
  ok "ChromAcS package install step finished"
}

create_launchers(){
  local bindir="$HOME/.local/bin"
  mkdir -p "$bindir"
  cat > "$bindir/chromacs" <<'EOS'
#!/usr/bin/env bash
[ "${CHROMACS_DEBUG:-}" = "1" ] && set -x
set -Eeuo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/.chromacs/CHROMACS}"
PY="$CONDA_HOME/envs/$ENV_NAME/bin/python"
ERRLOG="$HOME/.chromacs/run.err"

if [ "${1-}" = "--diag" ]; then
  echo "DISPLAY=${DISPLAY-}  WAYLAND_DISPLAY=${WAYLAND_DISPLAY-}"
  if [ -x "$PY" ]; then
    "$PY" - <<'PY' || true
import os, sys
print("Python:", sys.version)
try:
    import tkinter as tk
    r=tk.Tk(); print("Tk OK:", r.tk.call('info','patchlevel')); r.destroy()
except Exception as e:
    print("Tk test failed:", e)
try:
    import chromacs, chromacs.chromacs_13c as m
    print("chromacs:", getattr(chromacs,'__file__',None))
    print("chromacs_13c:", getattr(m,'__file__',None))
    print("has main():", hasattr(m, 'main'))
except Exception as e:
    print("import failed:", e)
PY
  else
    echo "No python at $PY"
  fi
  exit 0
fi

# 1) Installed package: import and call main()
if [ -x "$PY" ]; then
  if "$PY" - "$@" 2>"$ERRLOG" <<'PY'; then exit 0; fi
import sys
try:
    from chromacs.chromacs_13c import main as _main
except Exception as e:
    raise SystemExit(f"import chromacs main failed: {e}")
else:
    _main()
PY
fi

# 2) Repo module path + main()
if [ -x "$PY" ] && [ -d "$REPO_DIR/chromacs" ]; then
  if "$PY" - "$@" 2>"$ERRLOG" <<'PY'; then exit 0; fi
import os, sys
sys.path.insert(0, os.path.expanduser('~/.chromacs/CHROMACS'))
from chromacs.chromacs_13c import main as _main
_main()
PY
fi

# 3) Direct script fallback
if [ -x "$PY" ] && [ -f "$REPO_DIR/chromacs_13c.py" ]; then
  if "$PY" "$REPO_DIR/chromacs_13c.py" "$@" 2>"$ERRLOG"; then exit 0; fi
fi

echo "Failed to launch ChromAcS. See $ERRLOG"
exit 1
EOS
  chmod +x "$bindir/chromacs"

  cat > "$bindir/chromacs-addon" <<'EOS'
#!/usr/bin/env bash
[ "${CHROMACS_DEBUG:-}" = "1" ] && set -x
set -Eeuo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
REPO_DIR="${CHROMACS_REPO_DIR:-$HOME/.chromacs/CHROMACS}"
PY="$CONDA_HOME/envs/$ENV_NAME/bin/python"
ERRLOG="$HOME/.chromacs/run_addon.err"

# 1) Installed package
if [ -x "$PY" ]; then
  if "$PY" - "$@" 2>"$ERRLOG" <<'PY'; then exit 0; fi
import sys
try:
    from chromacs.chromacs_addon import main as _main
except Exception as e:
    raise SystemExit(f"import chromacs_addon main failed: {e}")
else:
    _main()
PY
fi

# 2) Repo
if [ -x "$PY" ] && [ -d "$REPO_DIR/chromacs" ]; then
  if "$PY" - "$@" 2>"$ERRLOG" <<'PY'; then exit 0; fi
import os, sys
sys.path.insert(0, os.path.expanduser('~/.chromacs/CHROMACS'))
from chromacs.chromacs_addon import main as _main
_main()
PY
fi

# 3) Direct
if [ -x "$PY" ] && [ -f "$REPO_DIR/chromacs_addon.py" ]; then
  if "$PY" "$REPO_DIR/chromacs_addon.py" "$@" 2>"$ERRLOG"; then exit 0; fi
fi

echo "Failed to launch ChromAcS add-on. See $ERRLOG"
exit 1
EOS
  chmod +x "$bindir/chromacs-addon"

  for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile" "$HOME/.zprofile"; do
    [ -f "$rc" ] || touch "$rc"
    if ! grep -q 'export PATH="$HOME/.local/bin' "$rc"; then
      echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$rc"
    fi
    if ! grep -q '\.chromacs/miniconda3/etc/profile.d/conda.sh' "$rc"; then
      echo 'if [ -f "$HOME/.chromacs/miniconda3/etc/profile.d/conda.sh" ]; then source "$HOME/.chromacs/miniconda3/etc/profile.d/conda.sh"; fi' >> "$rc"
    fi
  done
  ok "Launchers installed in $bindir"
}

verify_cli_tools(){
  local missing=0
  local tools="bowtie2 samtools fastqc multiqc trim_galore macs3 Genrich bedtools bamCoverage featureCounts aria2c fimo"
  for t in $tools; do
    if ! "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" bash -lc "command -v $t >/dev/null 2>&1"; then
      echo "MISSING: $t" | tee -a "$LOG"
      missing=1
    fi
  done
  [ $missing -eq 0 ] || fail "One or more CLI tools are missing. See $LOG for details."
  ok "All CLI tools found"
}

verify_r_packages(){
  "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" Rscript - <<'RS' || exit 71
    pkgs <- c("DiffBind","NOISeq","ChIPseeker","GenomicFeatures","GenomicRanges","rtracklayer","AnnotationDbi")
    miss <- c()
    for (p in pkgs){
      ok <- suppressWarnings(suppressMessages(requireNamespace(p, quietly=TRUE)))
      if(!ok) miss <- c(miss,p)
    }
    if(length(miss)>0){
      message("Missing R packages: ", paste(miss, collapse=", "))
      quit(status=2)
    } else {
      for(p in pkgs){
        cat(p, as.character(packageVersion(p)),"\n")
      }
    }
RS
  ok "All required R packages present"
}


info "=== $APP_NAME Windows (WSL) Installer v$VERSION ==="
install_miniconda
init_conda
fetch_repo
create_env_from_yml
pip_install_package

"$CONDA_HOME/bin/conda" install -y -n "$ENV_NAME" -c conda-forge -c bioconda \
  bowtie2 samtools fastqc multiqc macs3 genrich bedtools deeptools subread meme || fail "Failed to install core CLI tools"

"$CONDA_HOME/bin/conda" install -y -n "$ENV_NAME" bioconda::trim-galore || fail "Failed to install trim-galore"
"$CONDA_HOME/bin/conda" install -y -n "$ENV_NAME" conda-forge::aria2  || fail "Failed to install aria2"


"$CONDA_HOME/bin/conda" run -n "$ENV_NAME" Rscript - <<'RS' || true
  options(repos = c(CRAN="https://cloud.r-project.org"))
  if (!requireNamespace("BiocManager", quietly=TRUE)) install.packages("BiocManager")
  pkgs <- c("DiffBind","NOISeq","ChIPseeker","GenomicFeatures","GenomicRanges","rtracklayer","AnnotationDbi")
  need <- pkgs[!vapply(pkgs, function(p) requireNamespace(p, quietly=TRUE), logical(1))]
  if(length(need)>0) BiocManager::install(need, ask=FALSE, update=TRUE, quiet=TRUE)
RS

verify_cli_tools
verify_r_packages
create_launchers

echo; ok "$APP_NAME installation complete on Linux."
echo "Run: chromacs    or    chromacs-addon"
