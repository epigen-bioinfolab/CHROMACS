# ChromAcS-Install-Windows.ps1 — WSL launcher v1.2.8
$ErrorActionPreference='Stop'
function Pause-Exit([int]$code=0){Write-Host ""; Read-Host "Press Enter to close this window"; exit $code}

function Convert-ToWslPath([string]$p){
  try{$p=[System.IO.Path]::GetFullPath($p)}catch{return $null}
  if($p -match '^[A-Za-z]:\\'){
    $d=$p.Substring(0,1).ToLower()
    $r=$p.Substring(3).Replace('\','/')
    return "/mnt/{0}/{1}" -f $d,$r
  }
  return $null
}

try{Get-Command wsl -ErrorAction Stop|Out-Null}catch{
  Write-Host "WSL is not installed. Please install WSL + Ubuntu and run again."
  Pause-Exit 1
}

$dirWin=$PSScriptRoot; if(-not $dirWin){$dirWin=Split-Path -LiteralPath $MyInvocation.MyCommand.Path}
$dirWsl=Convert-ToWslPath $dirWin
if(-not $dirWsl){
  Write-Host "Could not convert folder to WSL path."
  Write-Host "Move the folder under C:\Users\<you>\Desktop or Downloads and retry."
  Pause-Exit 1
}

Write-Host "Windows folder: $dirWin"
Write-Host "WSL folder:    $dirWsl"
Write-Host ""

# Build a temp installer script inside WSL to avoid quoting issues
$guid=[guid]::NewGuid().ToString()
$wslTmp="$dirWsl/install_$guid.sh"

$payload = @'
set -e
cd '__WSL_DIR__'
if [ ! -f installer-win.sh ]; then echo 'installer-win.sh not found.'; exit 2; fi
chmod +x installer-win.sh
bash installer-win.sh
rc=$?
if [ $rc -eq 0 ]; then
  echo
  echo 'Install finished. Starting interactive shell - run: chromacs'
  exec bash -l
else
  echo
  echo 'Installer exited with error code' $rc
  exit $rc
fi
'@

$payload = $payload.Replace('__WSL_DIR__', $dirWsl)

$cmd = @"
cat > '$wslTmp' <<'EOS'
$payload
EOS
chmod +x '$wslTmp'
sed -i 's/\r$//' '$wslTmp'
bash '$wslTmp'
"@

& wsl -e bash -lc $cmd
