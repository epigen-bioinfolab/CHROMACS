#!/usr/bin/env bash
# ChromAcS Complete Installer (v2.2 - With MEME and Auto-Source)
set -Eeo pipefail

APP_NAME="ChromAcS"
WORK="$HOME/.chromacs"
REPO_URL="https://github.com/epigen-bioinfolab/CHROMACS.git"
REPO_DIR="${WORK}/CHROMACS"
ENV_NAME="chromacs"
CONDA_HOME="${WORK}/miniconda3"
LOG="${WORK}/install.log"

# Logging functions
ts(){ date +"%H:%M:%S"; }
info(){ echo "[INFO $(ts)] $*" | tee -a "$LOG"; }
warn(){ echo "[WARN $(ts)] $*" | tee -a "$LOG"; }
ok(){ echo "[OK   $(ts)] $*" | tee -a "$LOG"; }
fail(){ echo "[FAIL $(ts)] $*" | tee -a "$LOG"; exit 1; }

# System detection
OS="$(uname -s)"
ARCH="$(uname -m)"
is_macos(){ [ "$OS" = "Darwin" ]; }
is_linux(){ [ "$OS" = "Linux" ]; }
is_arm64(){ [ "$ARCH" = "arm64" ] || [ "$ARCH" = "aarch64" ]; }

# Utility functions
have(){ command -v "$1" >/dev/null 2>&1; }
mkdir -p "$WORK"; : > "$LOG"

install_xcode_cli_tools() {
    info "Installing Xcode Command Line Tools"
    
    if is_macos; then
        # Check if already installed
        if xcode-select -p &>/dev/null; then
            ok "Xcode CLI Tools already installed"
            return 0
        fi
        
        # Try to install CLI tools
        info "Please install Xcode Command Line Tools when prompted..."
        xcode-select --install 2>/dev/null
        
        # Wait for installation
        local max_wait=300
        local wait_time=0
        while [ ! -f /Library/Developer/CommandLineTools/usr/bin/git ] && [ $wait_time -lt $max_wait ]; do
            sleep 5
            wait_time=$((wait_time + 5))
            info "Waiting for Xcode CLI Tools installation... ($wait_time/$max_wait seconds)"
        done
        
        if [ -f /Library/Developer/CommandLineTools/usr/bin/git ]; then
            ok "Xcode CLI Tools installed successfully"
            return 0
        else
            fail "Xcode CLI Tools installation timed out. Please install manually from: https://developer.apple.com/download/all/"
        fi
    fi
    return 0
}

dl(){
    local url="$1" dest="$2"
    info "Downloading: $url"
    if have curl; then curl -fsSL --retry 5 --retry-all-errors -o "$dest" "$url" && return 0; fi
    if have wget; then wget -q -O "$dest" "$url" && return 0; fi
    if have python3; then
        python3 -c "import urllib.request; urllib.request.urlretrieve('$url', '$dest')" && return 0
    fi
    fail "No downloader available"
}

miniconda_url(){
    if is_macos; then
        is_arm64 && echo "https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-arm64.sh" || \
        echo "https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-x86_64.sh"
    else
        case "$ARCH" in
            x86_64) echo "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" ;;
            aarch64) echo "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-aarch64.sh" ;;
            *) echo "https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh" ;;
        esac
    fi
}

install_conda(){
    [ -x "$CONDA_HOME/bin/conda" ] && { ok "Miniconda already present"; return 0; }
    mkdir -p "$WORK/tmp"
    local sh="$WORK/tmp/miniconda.sh"
    dl "$(miniconda_url)" "$sh"
    bash "$sh" -b -p "$CONDA_HOME" >>"$LOG" 2>&1 || fail "Miniconda install failed"
    ok "Miniconda installed"
}

init_conda(){
    source "$CONDA_HOME/etc/profile.d/conda.sh" || fail "Could not source conda.sh"
    conda config --set channel_priority strict
    conda config --add channels conda-forge --add channels bioconda --add channels defaults
    conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main
    conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r
    ok "Conda configured"
}

fetch_repo(){
    # First try with git if available
    if have git; then
        if [ -d "$REPO_DIR/.git" ]; then
            info "Updating repository"
            git -C "$REPO_DIR" pull --ff-only || warn "git pull failed; continuing"
        else
            info "Cloning repository with git"
            git clone "$REPO_URL" "$REPO_DIR" || return 1
        fi
        ok "Repository ready"
        return 0
    fi
    
    # Fallback: download as zip
    warn "git not available; downloading as ZIP archive"
    local tmp="$WORK/tmp"
    mkdir -p "$tmp"
    local zip="$tmp/chromacs.zip"
    
    info "Downloading repository ZIP"
    dl "https://github.com/epigen-bioinfolab/CHROMACS/archive/refs/heads/main.zip" "$zip"
    
    # Clean previous installation
    rm -rf "$REPO_DIR"
    mkdir -p "$REPO_DIR"
    
    # Extract based on available tools
    if is_macos && [ -x /usr/bin/ditto ]; then
        /usr/bin/ditto -xk "$zip" "$tmp"
    elif have unzip; then
        unzip -q "$zip" -d "$tmp"
    elif have python3; then
        python3 -c "import zipfile; zipfile.ZipFile('$zip').extractall('$tmp')"
    else
        fail "No extraction tool available (need unzip or python3)"
    fi
    
    # Find and copy extracted content
    local src
    src="$(find "$tmp" -maxdepth 1 -type d -name 'CHROMACS-*' -o -name 'CHROMACS-main' | head -n1)"
    [ -n "$src" ] || fail "Could not find extracted repo folder"
    cp -R "$src"/. "$REPO_DIR"/
    ok "Repository downloaded and extracted"
    return 0
}

install_genrich_from_source(){
    info "Building Genrich from source"
    local tmp="$WORK/tmp/genrich"
    rm -rf "$tmp"; mkdir -p "$tmp"
    
    # Download Genrich
    dl "https://github.com/jsh58/Genrich/archive/refs/heads/master.zip" "$tmp/genrich.zip"
    
    # Extract
    if have unzip; then
        unzip -q "$tmp/genrich.zip" -d "$tmp"
    elif have python3; then
        python3 -c "import zipfile; zipfile.ZipFile('$tmp/genrich.zip').extractall('$tmp')"
    else
        warn "No extraction tool available for Genrich"
        return 1
    fi
    
    mv "$tmp/Genrich-master" "$tmp/Genrich" || mv "$tmp/Genrich-main" "$tmp/Genrich"
    
    # Build
    pushd "$tmp/Genrich" >/dev/null 2>&1
    make >>"$LOG" 2>&1 || { popd >/dev/null 2>&1; return 2; }
    
    # Install into conda environment
    "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" bash -c "cp '$tmp/Genrich/Genrich' \"\$CONDA_PREFIX/bin/\"" || { popd >/dev/null 2>&1; return 3; }
    popd >/dev/null 2>&1
    ok "Genrich built from source"
    return 0
}

install_meme(){
    info "Installing MEME Suite"
    
    # Try conda installation first
    if "$CONDA_HOME/bin/conda" install -n "$ENV_NAME" -c bioconda meme --yes >>"$LOG" 2>&1; then
        ok "MEME installed via conda"
        return 0
    fi
    
    # Fallback: build from source
    warn "Conda MEME installation failed, building from source..."
    local tmp="$WORK/tmp/meme"
    rm -rf "$tmp"; mkdir -p "$tmp"
    
    # Download MEME
    dl "https://meme-suite.org/meme/meme-software/5.5.3/meme-5.5.3.tar.gz" "$tmp/meme.tar.gz"
    
    # Extract
    tar -xzf "$tmp/meme.tar.gz" -C "$tmp"
    
    # Build
    pushd "$tmp/meme-5.5.3" >/dev/null 2>&1
    ./configure --prefix="$("$CONDA_HOME/bin/conda" run -n "$ENV_NAME" printenv CONDA_PREFIX)" >>"$LOG" 2>&1
    make >>"$LOG" 2>&1 || { popd >/dev/null 2>&1; return 2; }
    make install >>"$LOG" 2>&1 || { popd >/dev/null 2>&1; return 3; }
    popd >/dev/null 2>&1
    ok "MEME built from source"
    return 0
}

install_r_packages(){
    info "Installing R packages via Bioconductor"
    "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" Rscript - <<'RSCRIPT'
options(repos = c(CRAN = "https://cloud.r-project.org"))
if (!requireNamespace("BiocManager", quietly = TRUE)) {
    install.packages("BiocManager", repos = "https://cloud.r-project.org")
}

# Install Bioconductor packages with specific version handling
bioc_pkgs <- c("ChIPseeker", "DiffBind", "GenomicFeatures", "GenomicRanges", 
               "rtracklayer", "clusterProfiler", "txdbmaker", "biomaRt", "NOISeq")

for (pkg in bioc_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    tryCatch({
      # Try specific versions for problematic packages
      if (pkg == "DiffBind") {
        BiocManager::install("DiffBind", version = "3.18", ask = FALSE, update = TRUE)
      } else if (pkg == "ChIPseeker") {
        BiocManager::install("ChIPseeker", version = "3.18", ask = FALSE, update = TRUE)
      } else {
        BiocManager::install(pkg, ask = FALSE, update = TRUE)
      }
      Sys.sleep(2) # Add delay between installations
    }, error = function(e) {
      message("Failed to install ", pkg, ": ", e$message)
      # Try CRAN fallback for some packages
      if (pkg %in% c("ggplot2", "gridExtra")) {
        install.packages(pkg, repos = "https://cloud.r-project.org")
      }
    })
  }
}

# Install CRAN packages with retry logic
cran_pkgs <- c("ggplot2", "gridExtra", "R.utils", "xml2", "openxlsx", "ggrepel")
for (pkg in cran_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    tryCatch({
      install.packages(pkg, repos = "https://cloud.r-project.org")
      Sys.sleep(1)
    }, error = function(e) {
      message("Failed to install ", pkg, " from CRAN: ", e$message)
    })
  }
}

# Final verification
cat("Installed packages:\n")
for (pkg in c(bioc_pkgs, cran_pkgs)) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    cat("✓", pkg, "\n")
  } else {
    cat("✗", pkg, "\n")
  }
}
RSCRIPT
    ok "R packages installation attempted"
}

create_environment(){
    info "Creating conda environment"
    local yml="$WORK/tmp/environment-core.yml"
    cat > "$yml" <<'YAML'
name: chromacs
channels:
  - conda-forge
  - bioconda
  - defaults
dependencies:
  - python>=3.11,<3.13
  - r-base>=4.3.3
  - r-biocmanager
  - fontconfig

  # Core Python
  - pandas
  - numpy
  - scipy
  - statsmodels
  - pyyaml
  - openpyxl
  - matplotlib
  - seaborn
  - pillow

  # CLI Tools (universally available)
  - bowtie2
  - samtools
  - fastqc
  - multiqc
  - trim-galore
  - macs3
  - bedtools
  - deeptools
  - subread
  - aria2

  - pip
  - pip:
    - fpdf
    - TOBIAS
YAML

    "$CONDA_HOME/bin/conda" env create -n "$ENV_NAME" -f "$yml" || fail "Environment creation failed"
    
    # Install packages that might not be available via conda
    install_genrich_from_source || warn "Genrich installation failed (will use MACS3 only)"
    install_meme || warn "MEME installation failed"
    install_r_packages || warn "Some R packages failed to install"
    
    ok "Environment created with all possible packages"
}

install_chromacs(){
    info "Installing ChromAcS package"
    "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" pip install --no-cache-dir "$REPO_DIR" || fail "ChromAcS install failed"
    ok "ChromAcS installed"
}

create_launchers(){
    info "Creating launchers"
    local bindir="$HOME/.local/bin"
    mkdir -p "$bindir"
    
    cat > "$bindir/chromacs" <<'EOS'
#!/usr/bin/env bash
set -Eeuo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
exec "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" python -m chromacs.chromacs_13c "$@"
EOS

    cat > "$bindir/chromacs-addon" <<'EOS'
#!/usr/bin/env bash
set -Eeuo pipefail
CONDA_HOME="${CHROMACS_CONDA_HOME:-$HOME/.chromacs/miniconda3}"
ENV_NAME="${CHROMACS_ENV_NAME:-chromacs}"
exec "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" python -m chromacs.chromacs_addon "$@"
EOS

    chmod +x "$bindir/chromacs" "$bindir/chromacs-addon"
    
    # Add to PATH in all shell config files
    for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile" "$HOME/.bash_profile"; do
        if [ -f "$rc" ]; then
            if ! grep -q "\.local/bin" "$rc"; then
                echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$rc"
            fi
        else
            echo 'export PATH="$HOME/.local/bin:$PATH"' > "$rc"
        fi
    done
    
    # Source the configuration for current shell
    if [ -n "$BASH" ] && [ -f "$HOME/.bashrc" ]; then
        source "$HOME/.bashrc"
    elif [ -n "$ZSH_NAME" ] && [ -f "$HOME/.zshrc" ]; then
        source "$HOME/.zshrc"
    elif [ -f "$HOME/.profile" ]; then
        source "$HOME/.profile"
    fi
    
    export PATH="$HOME/.local/bin:$PATH"
    ok "Launchers created and PATH updated"
}

run_sanity_check(){
    info "Running comprehensive sanity check"
    local check_script="$REPO_DIR/chromacs-sanity-check.sh"
    [ -f "$check_script" ] || check_script="$(dirname "$0")/chromacs-sanity-check.sh"
    [ -f "$check_script" ] || { warn "Sanity check script not found"; return 1; }
    
    chmod +x "$check_script"
    "$check_script" || warn "Sanity check completed with some warnings"
    ok "Sanity check completed"
}

# Main installation process
info "=== ChromAcS Complete Installation ==="

# Install Xcode CLI tools first if on macOS
if is_macos; then
    install_xcode_cli_tools || fail "Xcode CLI Tools installation failed"
fi

install_conda
init_conda
fetch_repo || fail "Failed to fetch repository"
create_environment
install_chromacs
create_launchers
run_sanity_check

echo
ok "=== INSTALLATION COMPLETE ==="
echo "ChromAcS has been successfully installed!"
echo
echo "You can now run:"
echo "  chromacs        # Main application"
echo "  chromacs-addon  # Additional tools"
echo
echo "Installation log: $LOG"

# Test if commands work immediately
if command -v chromacs >/dev/null 2>&1; then
    echo
    echo "Testing installation..."
    if "$CONDA_HOME/bin/conda" run -n "$ENV_NAME" python -c "import chromacs; print('✓ ChromAcS imports successfully')"; then
        echo "✓ Installation verified successfully!"
    else
        echo "⚠ Installation completed but verification failed"
    fi
else
    echo "⚠ chromacs command not found in PATH. Please restart your terminal."
fi