ChromAcS — Automated Installer

• macOS →  Double Click on the file name:   ChromAcS-Install-MacOS.command

Once complete, launch the program by typing the following command in the terminal:

chromacs          # for main program

chromacs-addon    # for add-on 

NOTE:  if you get "Apple cannot verify this app" warning,     Go to System Preferences → Security & Privacy → General;  then   Click the "Open Anyway" button next to the warning message.

OR:    (1)   Right-click on ChromAcS-Install-MacOS.command   (2)  Select "Open" from the context menu   (3) Click "Open" in the security dialog that appears


# Alternate (1)

- right click on the INSTALL_CHROMACS.sh  and select "open in terminal"

# Alternate (2)

- Open a terminal:  you can use Spotlight search by pressing Command + Spacebar, typing "Terminal," and pressing Enter.
- Then run the following command in the terminal: 

        # cd <path-do-the-directory-where-chromacs-folder>  # example:  cd ~/Download/chromacs-mac
       
        `chmod +x INSTALL_CHROMACS.sh`
       `./INSTALL_CHROMACS.sh` 
       
NOTE: If you are behind a VPN/proxy and package downloads time out, configure your proxy and re‑run.
