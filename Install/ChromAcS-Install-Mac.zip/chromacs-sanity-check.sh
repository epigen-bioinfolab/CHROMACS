#!/usr/bin/env bash
# ChromAcS Comprehensive Sanity Check
set -uo pipefail

echo "=== ChromAcS Comprehensive Sanity Check ==="

ENV_NAME="${ENV_NAME:-chromacs}"
CONDA_HOME="${CONDA_HOME:-$HOME/.chromacs/miniconda3}"
CONDA_BIN="$CONDA_HOME/bin/conda"

# Check conda
if [ ! -x "$CONDA_BIN" ]; then
    echo "FAIL: Conda not found at $CONDA_BIN"
    exit 1
fi

if ! "$CONDA_BIN" env list | grep -qE "^\s*$ENV_NAME\s"; then
    echo "FAIL: Environment '$ENV_NAME' not found"
    exit 1
fi

# Helper function
in_env() {
    "$CONDA_BIN" run -n "$ENV_NAME" bash -c "$*" 2>/dev/null
}

echo
echo "1. Checking Core CLI Tools..."
CLI_TOOLS=("bowtie2" "samtools" "fastqc" "multiqc" "trim_galore" "macs3" "bedtools" "bamCoverage" "featureCounts" "aria2c")
for tool in "${CLI_TOOLS[@]}"; do
    if in_env "command -v $tool >/dev/null 2>&1"; then
        echo "  ✓ $tool"
    else
        echo "  ✗ $tool (MISSING)"
    fi
done

# Check Genrich (may be built from source)
if in_env "command -v Genrich >/dev/null 2>&1" || in_env "command -v genrich >/dev/null 2>&1"; then
    echo "  ✓ Genrich"
else
    echo "  ✗ Genrich (MISSING)"
fi

# Check MEME tools
if in_env "command -v meme >/dev/null 2>&1"; then
    echo "  ✓ MEME"
    if in_env "command -v fimo >/dev/null 2>&1"; then
        echo "  ✓ FIMO"
    else
        echo "  ✗ FIMO (MISSING)"
    fi
else
    echo "  ✗ MEME (MISSING)"
fi

echo
echo "2. Checking Python Packages..."
PY_PACKAGES=("pandas" "numpy" "scipy" "statsmodels" "matplotlib" "seaborn" "chromacs")
for pkg in "${PY_PACKAGES[@]}"; do
    if in_env "python -c 'import $pkg' 2>/dev/null"; then
        echo "  ✓ $pkg"
    else
        echo "  ✗ $pkg (MISSING)"
    fi
done

echo
echo "3. Checking R and Bioconductor Packages..."
R_CHECK=$(in_env "Rscript -e \"
pkgs <- c('BiocManager', 'ChIPseeker', 'DiffBind', 'GenomicFeatures', 'GenomicRanges', 
          'rtracklayer', 'clusterProfiler', 'ggplot2', 'gridExtra')
missing <- character()
for (pkg in pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    missing <- c(missing, pkg)
  }
}
if (length(missing) > 0) {
  cat('  MISSING:', paste(missing, collapse=', '), '\\n')
} else {
  cat('  ✓ All R packages installed\\n')
}
\"")

if [ -n "$R_CHECK" ]; then
    echo "$R_CHECK"
fi

echo
echo "4. Testing ChromAcS Import..."
if in_env "python -c 'import chromacs; print(\"  ✓ ChromAcS imports successfully\")'"; then
    true
else
    echo "  ✗ ChromAcS import FAILED"
fi

echo
echo "5. Testing Launchers..."
LAUNCHERS=("chromacs" "chromacs-addon")
for launcher in "${LAUNCHERS[@]}"; do
    if command -v "$launcher" >/dev/null 2>&1; then
        echo "  ✓ $launcher (in PATH)"
    elif [ -f "$HOME/.local/bin/$launcher" ]; then
        echo "  ✓ $launcher (in ~/.local/bin/)"
    else
        echo "  ✗ $launcher (MISSING)"
    fi
done

echo
echo "=== Sanity Check Complete ==="
echo "If any tools are missing, check the installation log: $HOME/.chromacs/install.log"